export interface Payload {
  username: string;
  seller: boolean;
  iat?: number;
  expiresIn?: string;
}
